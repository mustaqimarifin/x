import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { allNotes } from "contentlayer/generated";
import Balancer from "react-wrap-balancer";
import Tag from "components/Tag";
import { format, parseISO } from "date-fns";
import ViewCounter from "components/view-counter";

export async function generateStaticParams() {
  return allNotes.map((post) => ({
    slug: post.slug,
  }));
}

export default async function Notes({ params }) {
  const post = allNotes.find((post) => post.slug === params.slug);

  if (!post) {
    notFound();
  }

  return (
    <section>
      <h1 className="max-w-[650px] font-serif text-3xl font-bold">
        <Balancer>{post.title}</Balancer>
      </h1>
      <div className="mb-8 mt-4 grid max-w-[650px] grid-cols-[auto_1fr_auto] items-center font-mono text-sm">
        <div className="rounded-md bg-neutral-100 px-2 py-1 tracking-tighter dark:bg-neutral-800">
          {format(parseISO(post.date.start), "LLLL d, yyyy")}
        </div>

        <div className="mx-2 h-[0.2em] bg-neutral-50 dark:bg-neutral-800" />
        <ViewCounter slug={post.slug} trackView />
      </div>
      <div
        className="cl-post-body"
        dangerouslySetInnerHTML={{ __html: post.body.html }}
      />
    </section>
  );
}
