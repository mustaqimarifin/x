import type { Metadata } from "next";
import Link from "next/link";
import { allNotes } from "contentlayer/generated";
import ViewCounter from "components/view-counter";

export const metadata: Metadata = {
  title: "Notes",
  description: "Read my thoughts on software development, design, and more.",
};

export default async function NotesPage() {
  return (
    <section>
      <h1 className="mb-5 font-serif text-3xl font-bold">Notes</h1>
      {allNotes
        .sort((a, b) => {
          if (new Date(a.date.start) > new Date(b.date.start)) {
            return -1;
          }
          return 1;
        })
        .map((post) => (
          <Link
            key={post.slug}
            className="mb-4 flex flex-col space-y-1"
            href={`/notes/${post.slug}`}
          >
            <div className="flex w-full flex-col">
              <p>{post.title}</p>
              <ViewCounter slug={post.slug} trackView={false} />
            </div>
          </Link>
        ))}
    </section>
  );
}
