import { getPostDatabase } from "app/data";
import ViewCounter from "components/view-counter";
import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Works",
  description: "Read my thoughts on software development, design, and more.",
};

export default async function WorksIndex() {
  const works = await getPostDatabase();

  return (
    <section>
      <h1 className="mb-5 font-serif text-3xl font-bold">Works</h1>
      {works
        .sort((a, b) => {
          if (new Date(a.Date) > new Date(b.Date)) {
            return -1;
          }
          return 1;
        })
        .map((post) => (
          <Link
            key={post.Slug[0][0]}
            className="mb-4 flex flex-col space-y-1"
            href={`/works/${post.Slug[0][0]}`}
          >
            <div className="flex w-full flex-col">
              <p>{post.Title}</p>
              <ViewCounter slug={post.Slug[0][0]} trackView={false} />
            </div>
          </Link>
        ))}
    </section>
  );
}
