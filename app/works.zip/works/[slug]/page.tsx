import { notFound } from "next/navigation";
import { getTweets } from "lib/twitter";
import Balancer from "react-wrap-balancer";
import { PostDatabaseItem, getDatabasePage, getPostDatabase } from "app/data";
import ViewCounter from "components/view-counter";
import { NotionBlock } from "components/NotionBlock";
import { NotionRenderer } from "react-notion-x";
import dynamic from "next/dynamic";
import Link from "next/link";
import { ExtendedRecordMap } from "notion-types";
import { NotionAPI } from "notion-client";

export async function generateStaticParams() {
  const posts = await getPostDatabase();

  return posts.map((post) => ({
    id: post.id,
    slug: post.Slug[0][0],
  }));
}

export default async function WorksPage({
  params,
}: {
  params: { slug: string };
}) {
  const posts = await getPostDatabase();
  const postId = posts.find((p) => p.Slug[0][0] === params.slug)?.id;
  if (postId === undefined) {
    return <div>post not found</div>;
  }

  const { item: post, recordMap } = await getDatabasePage<PostDatabaseItem>(
    postId
  );

  return (
    <section>
      <h1 className="max-w-[650px] font-serif text-3xl font-bold">
        <Balancer>{post.Title}</Balancer>
      </h1>
      <div className="mb-8 mt-4 grid max-w-[650px] grid-cols-[auto_1fr_auto] items-center font-mono text-sm">
        <div className="rounded-md bg-neutral-100 px-2 py-1 tracking-tighter dark:bg-neutral-800">
          {post.Date}
        </div>
        <div className="mx-2 h-[0.2em] bg-neutral-50 dark:bg-neutral-800" />
        <ViewCounter slug={post.Slug[0][0]} trackView />
        {/*         { post.tags && (
          <div className="py-4 xl:py-8">

            <div className="flex flex-wrap">
              { post.tags.map((tag) => (
                <Tag key={ tag } text={ tag } />
              )) }
            </div>
          </div>
        ) } */}
      </div>
      <div className=" max-w-2xl">
        <NotionBlock blockId={postId} recordMap={recordMap} />
      </div>
    </section>
  );
}

/* const Collection = dynamic(() =>
  import('react-notion-x/build/third-party/collection').then(
    (m) => m.Collection
  )
) */
