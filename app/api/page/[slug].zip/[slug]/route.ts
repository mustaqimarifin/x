//import { routerClient } from "lib/supabase-server"
import supabase from "lib/supabase"
import { NextResponse } from "next/server"


export async function POST (request: Request) {
  const { slug } = await request.json()

  //const supabase = routerClient()



  const { data } = await supabase.rpc("increment_page_view", {
    page_slug: slug
  })
  return NextResponse.json(data)
}

export async function GET (request: Request) {
  const { slug } = await request.json()

  const { data } = await supabase
    .from("pageviews")
    .select("view_count")
    .eq("slug", slug)

  const total = !data.length ? 0 : Number(data[0].view_count) || null


  return NextResponse.json( total )
}
