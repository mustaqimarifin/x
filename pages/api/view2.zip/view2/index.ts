import prisma from 'lib/prisma'
import type { NextApiRequest, NextApiResponse } from 'next'

export default async function handler (
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const totalpost = await prisma.post.aggregate({
      _sum: {
        count: true
      }
    })

    return res
      .status(200)
      .json({ totalpost })
  } catch (e) {
    return res.status(500).json({ message: e })
  }
}
