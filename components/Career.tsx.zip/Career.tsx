'use client'
//import { Career as Deer, allCareers } from "contentlayer/generated"
import Link from "next/link"
import { ListContainer, ListItem } from "./List"
import { formatTags } from "lib/utils"

export const EXP = () => {
  //const items: Author[] = Array.from({ length: 5 }, (index) => index)
  return (
    <ListContainer>
      { allCareers.map((job: Deer) => {
        return (
          <ListItem key={ job.slug }>
            <div className="grid grid-cols-6 w-full gap-4 align-baseline" >
              <div className="col-start-1 col-end-7"

              >
                <div className="font-semibold">{ job.company }</div>
              </div>
              <div className="col-start-1 md:col-start-2 col-end-1 md:col-end-4  "

              >
                { job.description }

                { job.tags ? (
                  <>
                    <div className="inline-block" />
                    <div className="text-sm" >

                      <div className="absolute hidden w-1 h-1 whitespace-nowrap">Tools used:</div>

                      { formatTags(job.tags) }
                    </div>
                  </>
                ) : null }
              </div>
              <div className="col-start-1 md:col-start-4 col-end-1 md:col-end-4  "

              >

                <div className="text-sm" >
                  <div className="absolute hidden w-1 h-1 whitespace-nowrap">Duration</div>
                  { new Date(job.startDate).getFullYear() } &mdash;{ " " }
                  { job.endDate
                    ? new Date(job.endDate).getFullYear()
                    : "Now" }
                </div>
              </div>
            </div>
          </ListItem>
        )
      }) }
    </ListContainer>
  )
}